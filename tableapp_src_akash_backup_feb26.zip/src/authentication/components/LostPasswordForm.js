import React from 'react'

export function LostPasswordForm() {
	return (
		<form>
			<div>
				<h3>Lost Password Form</h3>
			</div>
		</form>
	)
}
