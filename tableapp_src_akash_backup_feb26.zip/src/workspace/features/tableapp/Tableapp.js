import React from 'react'
import { Card } from '../../../appkit'
import { PageTitle, ToggleHoverPanel } from './components'
import { BeatlesTable } from './beatles'

export function Tableapp() {
	return (
		<Card className="Tableapp-container">
			{/* <ToggleHoverPanel/> */}
			<PageTitle>Tableapp</PageTitle>
			<BeatlesTable/>
		</Card>
	)
}