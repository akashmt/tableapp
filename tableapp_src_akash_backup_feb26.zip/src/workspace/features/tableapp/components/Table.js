import React from 'react'
import styled from 'styled-components'

export const Table = ({ children }) => {
	return (
		<StyledTable>
			{children}
		</StyledTable>
	)
}

const StyledTable = styled.table`
	/* width: auto; */
`