import React from 'react'
import styled from 'styled-components'

export const TH = ({ children, colSpan}) => {
	return (
		<StyledTH colSpan={colSpan}>
			{children}
		</StyledTH>
	)
}

const StyledTH = styled.th`
	padding-left: 1.5rem !important;
`