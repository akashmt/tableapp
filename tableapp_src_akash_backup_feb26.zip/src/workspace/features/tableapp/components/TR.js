import React from 'react'
import styled from 'styled-components'

export const TR = ({ children }) => {
	return (
		<StyledTR>
			{children}
		</StyledTR>
	)
}

const StyledTR = styled.tr`
	color: #232323;
	background-color: white;
`