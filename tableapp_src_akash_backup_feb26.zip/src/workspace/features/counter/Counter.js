import React from 'react'
import { Card } from '../../../appkit'

export function Counter() {
	return (
		<Card className="Counter-container">
			<h1>Counter</h1>
		</Card>
	)
}