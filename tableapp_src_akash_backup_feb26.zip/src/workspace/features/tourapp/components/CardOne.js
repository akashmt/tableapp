import React from 'react'
import { Card } from '../../../../appkit'

export function CardOne() {
	return (
		<Card className="Dashboard-cardone" id="tour-card1">
			<h2>Transactions</h2>
			<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Reprehenderit, minus nihil. Inventore consequuntur hic dolor.</p>
		</Card>
	)
}