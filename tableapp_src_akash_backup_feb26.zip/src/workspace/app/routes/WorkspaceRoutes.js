import React from 'react'
import { Switch, Route } from 'react-router-dom'
import { Dashboard, Tableapp, Tabledemo, Flex, Chart, Counter, Tourapp } from '../../features'

export function WorkspaceRoutes() {
	return (
		<Switch>
			{/* <Route exact path="/workspace" component={Dashboard} /> */}
			<Route exact path="/workspace" component={Tableapp} />
			{/* <Route exact path="/workspace" component={Tabledemo} /> */}
			{/* <Route exact path="/workspace" component={Flex} /> */}
			{/* <Route exact path="/workspace" component={Chart} /> */}
			{/* <Route exact path="/workspace" component={Counter} /> */}
			{/* <Route exact path="/workspace" component={Tourapp} /> */}
		</Switch>
	)
}