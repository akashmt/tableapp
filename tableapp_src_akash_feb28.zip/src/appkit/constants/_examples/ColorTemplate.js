export const PRIMARY_COLOR = '' // #
export const PRIMARY_SHADE = '' // #
export const PRIMARY_TINT  = '' // #

export const SECONDARY_COLOR = '' // #
export const SECONDARY_SHADE = '' // #
export const SECONDARY_TINT  = '' // #

export const TERTIARY_COLOR = '' // #
export const TERTIARY_SHADE = '' // #
export const TERTIARY_TINT  = '' // #

export const SUCCESS_COLOR = '' // #
export const SUCCESS_SHADE = '' // #
export const SUCCESS_TINT  = '' // #

export const WARNING_COLOR = '' // #
export const WARNING_SHADE = '' // #
export const WARNING_TINT  = '' // #

export const DANGER_COLOR = '' // #
export const DANGER_SHADE = '' // #
export const DANGER_TINT  = '' // #

export const INFO_COLOR = '' // #
export const INFO_SHADE = '' // #
export const INFO_TINT  = '' // #

export const DARK_COLOR = '' // #
export const DARK_SHADE = '' // #
export const DARK_TINT  = '' // #

export const MEDIUM_COLOR = '' // #
export const MEDIUM_SHADE = '' // #
export const MEDIUM_TINT  = '' // #

export const LIGHT_COLOR = '' // #
export const LIGHT_SHADE = '' // #
export const LIGHT_TINT  = '' // #

export const BLACK_COLOR = '' // #
export const WHITE_SHADE = '' // #