export const FONTBASE = '16px'
export const LINEHIEGHT = '16px'
export const FONTFAMILY = '"Source Sans Pro", HelveticaNeue, Helvetica, Arial, Sans'