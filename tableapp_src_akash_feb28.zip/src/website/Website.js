import React from 'react'

export default function Website() {
	return (
		<section className="App-website">
			<h1>Website</h1>
			<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo totam exercitationem excepturi quos saepe fuga soluta quisquam temporibus, facilis nostrum. Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit ullam a officiis officia incidunt exercitationem, pariatur nihil dolor culpa nostrum.</p>
			<h2>Website</h2>
			<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo totam exercitationem excepturi quos saepe fuga soluta quisquam temporibus, facilis nostrum. Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit ullam a officiis officia incidunt exercitationem, pariatur nihil dolor culpa nostrum.</p>
			<ul>
				<li>One</li>
				<li>Two</li>
				<li>Three</li>
			</ul>
			<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo totam exercitationem excepturi quos saepe fuga soluta quisquam temporibus, facilis nostrum. Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit ullam a officiis officia incidunt exercitationem, pariatur nihil dolor culpa nostrum.</p>
		</section>
	)
}
