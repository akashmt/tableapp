import React from 'react'

export function ResetPasswordForm() {
	return (
		<form>
			<div>
				<h3>Reset Password Form</h3>
			</div>
		</form>
	)
}
