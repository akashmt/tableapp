import React from 'react'

export function RegisterForm() {
	return (
		<form>
			<div>
				<h3>Register Form</h3>
			</div>
		</form>
	)
}
