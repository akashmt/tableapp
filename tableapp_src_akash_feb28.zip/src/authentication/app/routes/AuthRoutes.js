import React from 'react'
import { Switch, Route } from 'react-router-dom'

export function AuthRoutes() {
	return (
		<Switch>
			{/* <Route exact path="/" component={Workspace} />
			<Route exact path="/" component={Dashboard} /> */}
		</Switch>
	)
}