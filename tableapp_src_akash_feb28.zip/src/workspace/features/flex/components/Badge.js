import React from 'react'
import styled from 'styled-components'

export function Badge() {
	return (
		<span>Lorem ipsum dolor sit amet.</span>
	)
}

const StyledBadge = styled.span`

`
