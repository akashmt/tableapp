import React from 'react'
import { Card } from '../../../appkit'

export function Chart() {
	return (
		<Card className="Charts-container">
			<h1>Chart</h1>
		</Card>
	)
}


