import React from 'react'

export const THead = ({ children }) => {
	return (
		<thead>
			{children}
		</thead>
	)
}