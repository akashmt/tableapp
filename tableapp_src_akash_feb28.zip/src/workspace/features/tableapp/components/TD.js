import React from 'react'
import styled from 'styled-components'

export const TD = ({ children }) => {
	return (
		<StyledTD>
			{children}
		</StyledTD>
	)
}

const StyledTD = styled.td``