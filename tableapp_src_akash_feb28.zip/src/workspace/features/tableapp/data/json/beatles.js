export const beatlesData = [
	{ id: 1, firstname: "John01", lastname: "Lennon", status: "single", active: "false", salary: 1000, age: 22 },
	{ id: 2, firstname: "Paul02", lastname: "McCarthy", status: "married", active: "false", salary: 1200, age: 32  },
	{ id: 3, firstname: "George", lastname: "Harrison",status: "single", active: "true", salary: 2000, age: 34  },
  { id: 4, firstname: "Ringo", lastname: "Star", status: "divorced", active: "true", salary: 1300, age: 30  },
  { id: 5, firstname: "Ricky", lastname: "Star", status: "divorced", active: "true", salary: 1400, age: 20  },
  { id: 6, firstname: "Matt", lastname: "Paul", status: "married", active: "false", salary: 1100, age: 43  }
]