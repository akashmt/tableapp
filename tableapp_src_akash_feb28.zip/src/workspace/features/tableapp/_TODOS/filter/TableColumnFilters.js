import React from 'react'
import { Table } from '../../components'

export function TableColumnFilters() {
	return (
		<Table>
			<h3>Table Column Filters</h3>
		</Table>
	)
}