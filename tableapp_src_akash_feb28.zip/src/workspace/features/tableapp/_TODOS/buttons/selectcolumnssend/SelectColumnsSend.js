import React from 'react'
import { Table, Caption, THead, TFoot, TBody, TR, TH, TD } from '../../../components'

// Make Settings Change and send to server

export function SelectColumnsSend() {
	return (
		<Table>
			<h3>Select Columns Send button</h3>
		</Table>
	)
}