import React from 'react'

export default function Modal() {
	return (
		<div>
			<h4>Modal</h4>
		</div>
	)
}
