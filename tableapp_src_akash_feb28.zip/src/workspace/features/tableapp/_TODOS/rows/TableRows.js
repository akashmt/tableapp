import React from 'react'
import { Table } from '../components'

export function TableRows() {
	return (
		<Table>
			<h3>Table Rows</h3>
		</Table>
	)
}