import React from 'react'
import { Table } from '../../../components'

// Single Column Select
// Multi Column Select
// Unselect Columm
// Cancel Select Button/Action
// ? Select Mode (switch button)

export default function SelectColumn() {
	return (
		<Table>
			<h3>Select Column</h3>
		</Table>
	)
}
