import React from 'react'
import { Table } from '../../../components'

export function FreezeColumn() {
	return (
		<Table>
			<h3>Freeze Column</h3>
		</Table>
	)
}
