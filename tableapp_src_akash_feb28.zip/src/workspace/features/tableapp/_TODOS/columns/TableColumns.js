import React from 'react'
import { Table } from '../../components'

export function TableColumns() {
	return (
		<Table>
			<h3>Table Columns</h3>
		</Table>
	)
}