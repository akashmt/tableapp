import React from 'react'
import { Table } from '../../../components'

export function CollapseColumn() {
	return (
		<Table>
			<h3>Collapse Column</h3>
		</Table>
	)
}
