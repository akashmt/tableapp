import React from 'react'
import { Table } from '../../../components'

export function ResizeColumnWidth() {
	return (
		<Table>
			<h3>Resize Column Width</h3>
		</Table>
	)
}