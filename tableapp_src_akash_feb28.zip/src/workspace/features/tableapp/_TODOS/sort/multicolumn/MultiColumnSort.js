import React from 'react'
import { Table } from '../../../components'

export function MultiColumnSort() {
	return (
		<Table>
			<h3>Multi Column Sort</h3>
		</Table>
	)
}