import React from 'react'
import { Card } from '../../../appkit'
import { PageTitle } from './components'
// import { BeatlesTable } from './beatles'
import { TableTemplate } from './template'
import { TextMatch, DropDown, DropDownBoolean, DropDownRange, RangeSelector, RangeSliderSelector } from './_TODOS/filter'
import { SelectRowsSend } from './_TODOS/buttons'
import { AscDsc,ClearAndReset } from './_TODOS/sort'
import { ReorderColumns } from './_TODOS/columns'

export const Tableapp = () => {

 
  function filterComponent(type) {
    switch (type) {
      case 'TextMatch':
        return <TextMatch/>;
      case 'DropDown':
        return <DropDown/>;
      case 'DropDownBoolean':
        return <DropDownBoolean/>;
      case 'DropDownRange':
        return <DropDownRange/>;
      case 'RangeSelector':
        return <RangeSelector/>;
      case 'RangeSliderSelector':
        return <RangeSliderSelector/>;
      default:
        return <TableTemplate/>;
    }
  }
	return (
		<Card className="Tableapp-container">
			<PageTitle>Tableapp</PageTitle>
      {/* <BeatlesTable/> */}
      {/* <TableTemplate/> */}
			{/* <TextMatch/> */}
      {/* <DropDown/> */}
      {/* <DropDownBoolean/> */}
      {/* <DropDownRange/> */}
      {/* <RangeSelector/> */}
      {/* <RangeSliderSelector/> */}

      {/* Options: TextMatch, DropDown, DropDownBoolean, DropDownRange, RangeSelector, RangeSliderSelector */}
      {/* {filterComponent('RangeSliderSelector')} */}

      {/* Button Examples */}
      {/* <SelectRowsSend/> */}

      {/* Sort Examples */}
      <AscDsc/>
      {/* <ClearAndReset/> */}

      {/* Columns Examples */}
      {/* <ReorderColumns/> */}

		</Card>
	)
}