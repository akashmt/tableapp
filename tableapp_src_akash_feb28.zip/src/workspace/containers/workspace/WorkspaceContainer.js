import React from 'react'

export const WorkspaceContent = ({children}) => {
	return (
		<>
			<Header/>
			<Main>
				Workspace Main
			</Main>
		</>
	)
}