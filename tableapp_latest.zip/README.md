# Tableapp
Create-React-App project for a Tableapp application to build out dynamic functionalities