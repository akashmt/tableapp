import React from 'react'

export function Home() {
	return (
		<>
			<h2>Home</h2>
			<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Libero magnam amet accusamus animi sapiente magni, hic iusto neque ipsam reprehenderit architecto corrupti sed error enim a itaque veniam dicta alias.</p>
		</>
	)
}