import React from 'react'
// import { LoginForm, RegisterForm, LostPasswordForm, ResetPasswordForm } from './components'

export default function Authentication() {
	return (
		<section className="App-authentication">
			<h1>Authentication</h1>
			{/* <LoginForm/> */}
		</section>
	)
}