import React from 'react'

export function AuthGridLayout() {
	return (
		<div>
			
		</div>
	)
}
