import React from 'react'
import { Card } from '../../../../appkit'

export function CardTwo() {
	return (
		<Card className="Dashboard-cardtwo">
			<h2>Salary</h2>
			<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Reprehenderit, minus nihil. Inventore consequuntur hic dolor.</p>
      <a className="button" href="/">Learn More</a>
		</Card>
	)
}