import React from 'react'
import styled from 'styled-components'
import 'rc-slider/assets/index.css';
import { Range } from 'rc-slider';
import { FaAngleDoubleRight, FaAngleDoubleLeft, FaEdit, FaArrowsAlt } from "react-icons/fa";
import { Table, Caption, THead, TFoot, TBody, TR, TH, TD } from '../components'

import { useGlobalState, handleTableCellFormat, useDeleteRowFunc, handleSelectionCellsFunc, handleSelectionRowsFunc, handleResizableColumnsFunc, usePaginationFunc, useSearchFunc, useDropdownFilterFunc, useColumnSortFunc, useColumnReorderFunc, useRowCheckboxFunc, useRowRadioFunc, useEditCellFunc, useCollapseColumnFunc, TableModalSwitcher, useMultiColumnSortFunc, useDataConditionColumnFilterFunc, useRangeSliderFunc } from './components'

export const SimpleTable = () => {
  const [state, dispatch] = useGlobalState();

 // Handle Data condition column filter
 const { handleDataConditionColumnFilter } = useDataConditionColumnFilterFunc(state,dispatch)

  // Handle Delete Row 
  const { handleRowDel } = useDeleteRowFunc(state,dispatch)
  // Handle Pagination 
  const { handleRecordPerPage, renderPerPageRecords, renderPageNumbers, currentPageRows } = usePaginationFunc(state,dispatch)

  // Handle Seacrh 
  const { handleSearch } = useSearchFunc(state,dispatch)

  // Handle Dropdown Filter
  const { handleDropdownOptionChange, handleDropdownOptionList } = useDropdownFilterFunc(state,dispatch)

  // Handle Column Sort
  const { handleColumnSort, handleColumnDirection } = useColumnSortFunc(state,dispatch)

  // Handle Column reorder
  const { handleDragStart, handleDragOver, handleDragEnter, handleOnDrop } = useColumnReorderFunc(state,dispatch)

  // Handle Rowcheckbox selection
  const { handleRowAllCheckBox, handleRowCheckBoxFields } = useRowCheckboxFunc(state,dispatch)

  // Handle Radio for row selection
  const { handleRowRadioFields } = useRowRadioFunc(state,dispatch)

  // Handle Editable Cell
  const { enableEditTableCell, handleEditTableCell, disableEditTableCell } = useEditCellFunc(state,dispatch)

  // Handle collpase column
  const { handleCollapseColumn } = useCollapseColumnFunc(state,dispatch)

  // Handle range slider
  const { handleRangeSlider } = useRangeSliderFunc(state,dispatch)

  
  const { handleUserGearTableSetting, handleMulticolumnSort, handleTableReset } = useMultiColumnSortFunc(state,dispatch)

  React.useEffect(() => {

    handleResizableColumnsFunc()
    handleDataConditionColumnFilter()
    if(state.tableData.table.isSelection === 'rows') {
      handleSelectionRowsFunc();
    } 
    if(state.tableData.table.isSelection === 'cells') {
      handleSelectionCellsFunc();
    }
  },[]);
  console.log(state.tableData)
  const numericSet = ['currency','number', 'percent']
  const displayColumns = state.tableData.table.columns.filter(column => {
    return column.hidden === false
  })

  const stateValue= {
    sortBy: state.sortBy,
    columns: displayColumns
  }
  
  return (
    <StyleTable>
      <Table id="table">
        <Caption>
          Tutorial Table
          {state.tableData.table.isUserGearTableSetting ?
            <TableModalSwitcher
              stateValue={stateValue}
              handleChange={handleUserGearTableSetting} 
              handleSort={handleMulticolumnSort} 
              handleReset={handleTableReset}
            />
          : null
          }

        </Caption>
        <THead>
          <TR>
           {state.tableData.table.selectRow !== '' && state.tableData.table.selectRow === 'checkbox'
            ?
              <TH><input type="checkbox" name="name1" onChange={handleRowAllCheckBox} checked={state.rowHeaderCheckbox} /></TH>
            : state.tableData.table.selectRow !== '' && state.tableData.table.selectRow === 'radio' ?
              <TH></TH>
            : null
            }
            {displayColumns.map((column,index) => {
              return (
                <TH key={index} className={state.expandedColumns.includes(column.name) ? 'expanded' : 'collapsed'}>
                   <span className="dragelement"
                     id={column.name}
                     draggable
                     onDragStart={handleDragStart}
                     onDragOver={handleDragOver}
                     onDrop={handleOnDrop}
                     onDragEnter={handleDragEnter}
                     dragOver={column.name === state.dragOver}  
                  >
                    {column.isCollapse ?
                      state.expandedColumns.includes(column.name) ? 
                      <><FaAngleDoubleLeft  onClick={()=>handleCollapseColumn(column.name)}/> {column.headerText} </> : 
                      <div className="tooltip"><FaAngleDoubleRight onClick={()=>handleCollapseColumn(column.name)}/>
                        <span className="tooltiptext">{column.headerText}</span>
                      </div>
                    : column.headerText}
                  </span>
                </TH>
              )
            })}
            {state.tableData.table.deleteRow ?
              <TH>Action</TH>
            : null
            }
          </TR>
          <TR>
            {state.tableData.table.selectRow 
            ?
              <TH></TH>
            : null
            }
            {displayColumns.map((column,index) => {
              return (
                column.defaultFilter === 'search' ?
                  <TH key={index}><input type="search" name={column.name} onChange={(e) => handleSearch(e, column.name)} /></TH>
                :
                column.defaultFilter === 'dropdown' ?
                  <TH key={index}>
                    <select onChange={(e) => handleDropdownOptionChange(e, column.name)}>
                      <option value="">Choose Option</option>
                      {handleDropdownOptionList(column.name)}
                    </select>
                  </TH>
                : column.defaultFilter === 'sort' ?
                  <TH key={index}>
                    <span onClick={()=>handleColumnSort(column.name)}>Sort {handleColumnDirection(column.name)}</span>
                  </TH>
                : column.defaultFilter === 'rangeSlider' ?
                  <TH key={index}>
                    <Range defaultValue={[column.defaultSliderValues[0], column.defaultSliderValues[1]]} min={column.defaultSliderValues[0]} max={column.defaultSliderValues[1]} onChange={(e)=>handleRangeSlider(e,column.name,index)} /> <br/>
                    {column.rangeSliderValues ?
                    <strong>Range: {column.rangeSliderValues[0]}-{column.rangeSliderValues[1]}</strong>
                    : null}
                  </TH>
                : <TH key={index}></TH>
              )
            })}
          </TR>
        </THead>

        
        <TBody>
          {currentPageRows.map((row,index) => {
            return (
            <TR key={index}> 
              { state.tableData.table.selectRow !== '' && state.tableData.table.selectRow === 'checkbox' 
                ? <TD><input type="checkbox" name="name1" onChange={() => handleRowCheckBoxFields(row, index)} checked={state.rowCheckboxFields[index].checked} /></TD>
              : state.tableData.table.selectRow !== '' && state.tableData.table.selectRow === 'radio' ?
                <TH><input type="radio" name="name1" value={index} onChange={(e) => handleRowRadioFields(index)} checked={state.rowRadioFields === index} /></TH>
              : null
              }
              {displayColumns.map((column,index) => {
                return (
                  <TD className={numericSet.indexOf(column.dataType) > -1 ? 'alignright' : ''} key={index} onClick={()=>disableEditTableCell()} dragOver={column.name === state.dragOver}>
                    {state.editCell === column.name+'_'+row.key ?
                        <input type='text' name={column.name} id={row.key} defaultValue={row[column.name]} onClick={(e) => { e.stopPropagation()}} onChange={(evt)=>handleEditTableCell(evt)} />
                    :
                    <> {column.isCollapse ? 
                          state.expandedColumns.includes(column.name) ?
                            handleTableCellFormat(column.dataType, column.formatString, column.precision, row[column.name]) 
                          : null
                        : handleTableCellFormat(column.dataType, column.formatString, column.precision, row[column.name])}
                    </>
                    }
                    {state.tableData.table.editableCell ?
                      <span className="editicon" onClick={()=>enableEditTableCell(row.key, column.name)}><FaEdit/></span>
                    : null}
                  </TD>
                )
              })}
               {state.tableData.table.deleteRow ?
               <TD key={index}> 
                <input type="button" onClick={() => { if (window.confirm('Are you sure you wish to delete this row?')) handleRowDel(row) } } value="X"/>
              </TD>
              : null}
            </TR>
            )
          })}
        </TBody>
        <TFoot>
          <TR>
            <TH colSpan={displayColumns.length}>(c) footer</TH>
          </TR>
          <TR>
              <TH>
                <select value={state.recordPerPage} onChange={(e) => handleRecordPerPage(e)}>
                  <option value={state.tableData.table.recordPerPage}>Records Per Page</option>
                  {renderPerPageRecords()}
                </select>
              </TH>
              <TH>
                <ul id="page-numbers">
                  {renderPageNumbers()}
                </ul>
              </TH>
            </TR>
        </TFoot>
      </Table>
    </StyleTable>
  )
}
const StyleTable = styled.div`
  td, th {
    border: 0.1rem solid #e1e1e1;
    &.alignright {
      text-align: right;
    }
  }
  tr, td {
    &.selected {
      background-color: grey;
    }
  }
  span.dragelement{
    display: block;
    cursor: move;
  }
  span.dragelement svg {
    float: right;
  }
  td span.editicon {
    float: right;
    cursor: pointer;
  }
  /* collapse column */
  table {
    table-layout: fixed;
  }
  th {
    width: 150px;
    transition: all 0.1s;
  }
  thead tr th.collapsed {
    width: 50px;
  }

  /* Tooltip container */
  .tooltip {
    cursor: pointer;
    position: relative;
    display: inline-block;
    border-bottom: 1px dotted black; /* If you want dots under the hoverable text */
  }
  
  /* Tooltip text */
  .tooltip .tooltiptext {
    visibility: hidden;
    width: 120px;
    background-color: #555;
    color: #fff;
    text-align: center;
    padding: 5px 0;
    border-radius: 6px;
  
    /* Position the tooltip text */
    position: absolute;
    z-index: 1;
    bottom: 125%;
    left: 50%;
    margin-left: -60px;
  
    /* Fade in tooltip */
    opacity: 0;
    transition: opacity 0.3s;
  }
  
  /* Tooltip arrow */
  .tooltip .tooltiptext::after {
    content: "";
    position: absolute;
    top: 100%;
    left: 50%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: #555 transparent transparent transparent;
  }
  
  /* Show the tooltip text when you mouse over the tooltip container */
  .tooltip:hover .tooltiptext {
    visibility: visible;
    opacity: 1;
  }
`


