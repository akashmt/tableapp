import React from 'react'
import { Switch, Route } from 'react-router-dom'
import { Card } from '../../../appkit'
import { PageTitle } from './components'
import { SimpleTable } from './simpletable'
import { GlobalStateProvider } from './simpletable/components'


export const Tutorial = () => {
	return (
    <GlobalStateProvider>
      <Card className="Tableapp-container">
        <PageTitle>Tutorial</PageTitle>
        <Switch>
          <Route exact path="/workspace/tutorial" component={SimpleTable} />
        </Switch>
      </Card>
    </GlobalStateProvider>
	)
}