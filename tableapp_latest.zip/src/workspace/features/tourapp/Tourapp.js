import React from 'react'
import { Card } from '../../../appkit'
import { Dashboard } from './Dashboard'

export function Tourapp() {
	return (
		<Card className="Tourapp-container">
			<Dashboard/>
		</Card>
	)
}
