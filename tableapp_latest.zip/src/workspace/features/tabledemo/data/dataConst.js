export const accountsData = [
  {
    id: 1,
    name: "Slade",
    type: "type1",
    accountingTime: "13:25",
    moveTime: "13:26",
    amount: 123,
    securitizationOwner: "AirBank"
  },{
    id: 2,
    name: "Finn",
    type: "type2",
    accountingTime: "14:25",
    moveTime: "14:26",
    amount: 456,
    securitizationOwner: "HC"
  },{
    id: 3,
    name: "Fay",
    type: "type3",
    accountingTime: "15:25",
    moveTime: "15:26",
    amount: 789,
    securitizationOwner: "AB"
  },{
    id: 4,
    name: "Eleanor",
    type: "type1",
    accountingTime: "16:25",
    moveTime: "16:26",
    amount: 1234,
    securitizationOwner: "HomeCredit"
    
  },{
    id: 5,
    name: "Brock",
    type: "type5",
    accountingTime: "17:25",
    moveTime: "17:26",
    amount: 12345,
    securitizationOwner: "HomeCredit"
  },{
    id: 6,
    name: "Garth",
    type: "type1",
    accountingTime: "13:25",
    moveTime: "13:26",
    amount: 123,
    securitizationOwner: "AirBank"
  },{
    id: 7,
    name: "Guy",
    type: "type2",
    accountingTime: "14:25",
    moveTime: "14:26",
    amount: 456,
    securitizationOwner: "HomeCredit"
  },{
    id: 8,
    name: "Joy",
    type: "type3",
    accountingTime: "15:25",
    moveTime: "15:26",
    amount: 789,
    securitizationOwner: "AirBank"
  },{
    id: 9,
    name: "Prescott",
    type: "type1",
    accountingTime: "16:25",
    moveTime: "16:26",
    amount: 1234,
    securitizationOwner: "HomeCredit"
  },{
    id: 10,
    name: "Rose",
    type: "type5",
    accountingTime: "17:25",
    moveTime: "17:26",
    amount: 12345,
    securitizationOwner: "HomeCredit"
  },{
    id: 11,
    name: "Ray",
    type: "type1",
    accountingTime: "13:25",
    moveTime: "13:26",
    amount: 123,
    securitizationOwner: "AirBank"
  },{
    id: 12,
    name: "Timon",
    type: "type2",
    accountingTime: "14:25",
    moveTime: "14:26",
    amount: 456,
    securitizationOwner: "HomeCredit"
  },{
    id: 13,
    name: "Yasir",
    type: "type3",
    accountingTime: "15:25",
    moveTime: "15:26",
    amount: 789,
    securitizationOwner: "AirBank"
  },{
    id: 14,
    name: "Kevin",
    type: "type1",
    accountingTime: "16:25",
    moveTime: "16:26",
    amount: 1234,
    securitizationOwner: "HomeCredit"
  },{
    id: 15,
    name: "Jerome",
    type: "type5",
    accountingTime: "17:25",
    moveTime: "17:26",
    amount: 12345,
    securitizationOwner: "HomeCredit"
  },{
    id: 16,
    name: "Susan",
    type: "type1",
    accountingTime: "13:25",
    moveTime: "13:26",
    amount: 123,
    securitizationOwner: "AirBank"
  },{
    id: 17,
    name: "Harding",
    type: "type2",
    accountingTime: "14:25",
    moveTime: "14:26",
    amount: 456,
    securitizationOwner: "HomeCredit"
  },{
    id: 18,
    name: "Olivia",
    type: "type3",
    accountingTime: "15:25",
    moveTime: "15:26",
    amount: 789,
    securitizationOwner: "AirBank"
  },{
    id: 19,
    name: "August",
    type: "type1",
    accountingTime: "16:25",
    moveTime: "16:26",
    amount: 1234,
    securitizationOwner: "HomeCredit"
  },{
    id: 20,
    name: "Indira",
    type: "type5",
    accountingTime: "17:25",
    moveTime: "17:26",
    amount: 12345,
    securitizationOwner: "HomeCredit"
  },{
    id: 21,
    name: "Reed",
    type: "type1",
    accountingTime: "13:25",
    moveTime: "13:26",
    amount: 123,
    securitizationOwner: "AirBank"
  },{
    id: 22,
    name: "Zeph",
    type: "type2",
    accountingTime: "14:25",
    moveTime: "14:26",
    amount: 456,
    securitizationOwner: "HomeCredit"
  },{
    id: 23,
    name: "Uriel",
    type: "type3",
    accountingTime: "15:25",
    moveTime: "15:26",
    amount: 789,
    securitizationOwner: "AirBank"
  },{
    id: 24,
    name: "Raymond",
    type: "type1",
    accountingTime: "16:25",
    moveTime: "16:26",
    amount: 1234,
    securitizationOwner: "HomeCredit"
  },{
    id: 25,
    name: "Sebastian",
    type: "type5",
    accountingTime: "17:25",
    moveTime: "17:26",
    amount: 12345,
    securitizationOwner: "HomeCredit"
  },{
    id: 26,
    name: "Carter",
    type: "type1",
    accountingTime: "13:25",
    moveTime: "13:26",
    amount: 123,
    securitizationOwner: "AirBank"
  },{
    id: 27,
    name: "Jermaine",
    type: "type2",
    accountingTime: "14:25",
    moveTime: "14:26",
    amount: 456,
    securitizationOwner: "HomeCredit"
  },{
    id: 28,
    name: "Rhonda",
    type: "type3",
    accountingTime: "15:25",
    moveTime: "15:26",
    amount: 789,
    securitizationOwner: "AirBank"
  },{
    id: 29,
    name: "Minerva",
    type: "type1",
    accountingTime: "16:25",
    moveTime: "16:26",
    amount: 1234,
    securitizationOwner: "HomeCredit"
  },{
    id: 30,
    name: "Lucas",
    type: "type5",
    accountingTime: "17:25",
    moveTime: "17:26",
    amount: 12345,
    securitizationOwner: "HomeCredit"
  },{
    id: 31,
    name: "Jessica",
    type: "type1",
    accountingTime: "13:25",
    moveTime: "13:26",
    amount: 123,
    securitizationOwner: "AirBank"
  },{
    id: 32,
    name: "Slade",
    type: "type2",
    accountingTime: "14:25",
    moveTime: "14:26",
    amount: 456,
    securitizationOwner: "HomeCredit"
  },{
    id: 33,
    name: "Jessica",
    type: "type3",
    accountingTime: "15:25",
    moveTime: "15:26",
    amount: 789,
    securitizationOwner: "AirBank"
  },{
    id: 34,
    name: "Michael",
    type: "type1",
    accountingTime: "16:25",
    moveTime: "16:26",
    amount: 1234,
    securitizationOwner: "HomeCredit"
  },{
    id: 35,
    name: "Bianca",
    type: "type5",
    accountingTime: "17:25",
    moveTime: "17:26",
    amount: 12345,
    securitizationOwner: "HomeCredit"
  },{
    id: 36,
    name: "Craig",
    type: "type1",
    accountingTime: "13:25",
    moveTime: "13:26",
    amount: 123,
    securitizationOwner: "AirBank"
  },{
    id: 37,
    name: "Armand",
    type: "type2",
    accountingTime: "14:25",
    moveTime: "14:26",
    amount: 456,
    securitizationOwner: "HomeCredit"
  },{
    id: 38,
    name: "Brenda",
    type: "type3",
    accountingTime: "15:25",
    moveTime: "15:26",
    amount: 789,
    securitizationOwner: "AirBank"
  },{
    id: 39,
    name: "Zenia",
    type: "type1",
    accountingTime: "16:25",
    moveTime: "16:26",
    amount: 1234,
    securitizationOwner: "AirBank"
  },{
    id: 40,
    name: "Ashton",
    type: "type5",
    accountingTime: "17:25",
    moveTime: "17:26",
    amount: 12345,
    securitizationOwner: "HomeCredit"
  }
]