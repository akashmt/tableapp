switch () {
	if less than 10, use Dropdown
} else if {
	if more than 10, use TextMatch
} else if {
	is range, use RangeSelector
}