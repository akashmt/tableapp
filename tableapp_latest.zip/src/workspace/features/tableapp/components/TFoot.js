import React from 'react'

export const TFoot = ({ children }) => {
	return (
		<tfoot>
			{children}
		</tfoot>
	)
}