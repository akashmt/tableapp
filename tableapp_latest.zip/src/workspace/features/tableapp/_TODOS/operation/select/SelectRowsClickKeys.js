import React from 'react'
import styled from 'styled-components'
import { Table, Caption, THead, TFoot, TBody, TR, TH, TD } from '../../../components'
import { beatlesData } from '../../../data/json/beatles'

export class SelectRowsClickKeys extends React.Component {

  constructor(){
    super();
    this.state = {
      beatles: beatlesData,
      columns: Object.keys(beatlesData[0])
    }
  }
	

componentDidMount() {
  var lastSelectedRow;
  var trs = document.getElementById('table').querySelectorAll("tr")

  trs.forEach(evt => evt.addEventListener("mousedown", function(e) {
    RowClick(this,false)
  }))

  // disable text selection
  document.onselectstart = function() {
      return false;
  }

  function RowClick(currenttr) {
      if (window.event.ctrlKey) {
          toggleRow(currenttr);
      }
      
      if (window.event.button === 0) {
          if (!window.event.ctrlKey && !window.event.shiftKey) {
              clearAll();
              toggleRow(currenttr);
          }
      
          if (window.event.shiftKey) {
              selectRowsBetweenIndexes([lastSelectedRow.rowIndex, currenttr.rowIndex])
          }
      }
  }

  function toggleRow(row) {
      row.className = row.className === 'selected' ? '' : 'selected';
      lastSelectedRow = row;
  }

  function selectRowsBetweenIndexes(indexes) {
      indexes.sort(function(a, b) {
          return a - b;
      });
      clearAll()
      for (var i = indexes[0]; i <= indexes[1]; i++) {
          trs[i].className = 'selected';
      }
  }

  function clearAll() {
      for (var i = 0; i < trs.length; i++) {
          trs[i].className = '';
      }
  }
}



	render() {
    const { beatles, columns } = this.state
    
		return (
      <StyleTable>
        <Table id="table">
          <Caption>Highlight Selected Table Rows on click toggle</Caption>
          <THead>
            <TR>
              {columns.map((col, index) => (
                <TH key={index}>{col}</TH>
              ))}
            </TR>
          </THead>
          <TBody>
            {beatles.map((beatle, index) => (
                <TR key={index}>
                  {columns.map((col, index) => (
                  <TD key={index}>{beatle[col]}</TD>
                  ))}
                </TR>
            ))}
          </TBody>
          <TFoot>
            <TR>
              <TH colSpan="7">(c) footer</TH>
            </TR>
          </TFoot>
        </Table>
      </StyleTable>
		)
	}
}

const StyleTable = styled.div`
  td, th {
    border: 0.1rem solid #e1e1e1;
    padding: 1.2rem 1.5rem;
  }
  tr.selected {
    background-color: Green;
  }
` 
