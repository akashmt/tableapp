import React from 'react'
import styled from 'styled-components'
import { FaMinusCircle } from "react-icons/fa";
import { Table, Caption, THead, TFoot, TBody, TR, TH, TD } from '../../../components'
import { beatlesData } from '../../../data/json/beatles'

export class DeleteColumn extends React.Component {
	state = {
    beatles: beatlesData,
    columns: Object.keys(beatlesData[0])
  }

  handleColumnDel(column) {
    var index = this.state.columns.indexOf(column);
    this.state.columns.splice(index, 1);
    this.setState({columns: this.state.columns});
  };
 

	render() {
    const { beatles, columns } = this.state
    console.log(beatles)
    
		return (
      <StyleTable>
        <Table>
          <Caption>
              Delete Table Row 
          </Caption>
          <THead>
            <TR>
              {columns.map((col, index) => (
                <TH key={index}>{col} <a className="deleteicon" href="javascrip:void(0)" onClick={() => { if (window.confirm('Are you sure you wish to delete this column?')) this.handleColumnDel(col) } }><FaMinusCircle /></a></TH>
              ))}
            </TR>
          </THead>
          <TBody>
            {beatles.map((beatle, index) => (
                <TR key={index}>
                  {columns.map((col, index) => (
                  <TD>
                    {beatle[col]}
                  </TD>
                  ))}
                </TR>
            ))}
          </TBody>
          <TFoot>
            <TR>
              <TH colSpan="8">(c) footer</TH>
            </TR>
          </TFoot>
        </Table>
      </StyleTable>
		)
	}
}

const StyleTable = styled.div`
  td, th {
    border: 0.1rem solid #e1e1e1;
    padding: 1.2rem 1.5rem;
    input {
      color: WHITE;
    }
  }
  a.deleteicon {
    float: right;
  }
` 
