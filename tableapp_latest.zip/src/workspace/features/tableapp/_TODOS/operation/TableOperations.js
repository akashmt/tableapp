import React from 'react'
import { Table } from '../../components'

export function TableOperations() {
	return (
		<Table>
			<h3>Table Operations</h3>
		</Table>
	)
}