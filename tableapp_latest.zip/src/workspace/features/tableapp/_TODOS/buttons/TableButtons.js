import React from 'react'
import { Table, Caption, THead, TFoot, TBody, TR, TH, TD } from '../../components'

export function TableButtons() {
	return (
		<Table>
			<h3>Table Buttons</h3>
		</Table>
	)
}