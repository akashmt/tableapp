import React from 'react'
import { FaSort, FaSortUp, FaSortDown } from "react-icons/fa";
import { Table, Caption, THead, TFoot, TBody, TR, TH, TD } from '../../../components'
import { ModalSwitcher } from './components/sortmodalswitcher'
import { multisortData } from '../../../data/json/beatles'

export class MultiColumnSort extends React.Component {

  constructor(props){
    super(props)
    this.state = {
      beatles: [...multisortData],
      columns: Object.keys(multisortData[0]),
      sortBy: Object.keys(multisortData[0]).map((col) => { return { column: '', direction:'asc'} } )
    }
  }

  handleChange = (e, index) => {
    const sortByCopy = [...this.state.sortBy]
    
    if(e.target.name == index) {
      sortByCopy[index] = {...sortByCopy[index],'direction': e.target.value} 
    } else {
      sortByCopy[index] = {...sortByCopy[index], [e.target.name]: e.target.value} 
    }
    this.setState({sortBy: sortByCopy})
  }

  handleReset = () => {
    this.setState({sortBy: this.state.columns.map(() => { return { column: '', direction:"asc"} }) })
  }


  handleSort = (e) => {
    e.preventDefault()
    const { sortBy } = this.state
    let arrayCopy = [...multisortData]

    const sortColumn = this.state.sortBy.filter((s) => {
      return s.column !== ''
    })
   
    arrayCopy.sort(function(a, b) {
      
        if(sortBy[0].direction === 'asc') {
          if (a[sortBy[0].column] > b[sortBy[0].column]) {
            return 1;
          } else if (a[sortBy[0].column] < b[sortBy[0].column]) { 
              return -1;
          }
        } else {
          if (a[sortBy[0].column] < b[sortBy[0].column]) {
            return 1;
          } else if (a[sortBy[0].column] > b[sortBy[0].column]) { 
              return -1;
          }
        }
    
         // Else go to the other item
         for (var i = 1; i < sortColumn.length; i++) {
          if(sortBy[i].direction === 'asc') {
            if (a[sortBy[i].column] > b[sortBy[i].column]) { 
                return 1;
            } else if (a[sortBy[i].column] < b[sortBy[i].column]) {
                return -1
            } 
          } else {
            if (a[sortBy[i].column] < b[sortBy[i].column]) { 
              return 1;
            } else if (a[sortBy[i].column] > b[sortBy[i].column]) {
                return -1
            }
          } 
        }
    });
    
    this.setState({beatles: arrayCopy})

  }


	render() {
		const { beatles, columns } = this.state
    console.log(this.state.sortBy)
		return (
			<Table>
				<Caption>
          SortBy Multi Column Demo
          <ModalSwitcher stateValue={this.state} handleChange={this.handleChange} handleSort={this.handleSort} handleReset={this.handleReset}  />
        </Caption>
        
				<THead>
					<TR>
              {columns.map((col, index) => (
                <TH key={index}>{col}</TH>
              ))}
					</TR>
				</THead>
				<TBody>
        {beatles.map((beatle, index) => {
          return ( 
            <TR key={index}>
              {columns.map((col, index) => {
                return(
                  <TD key={index}>{beatle[col]}</TD>
                )
              })}
            </TR>
          )
        })}
				</TBody>
        <TFoot>
					<TR>
						<TH colSpan={columns.length}>(c) footer</TH>
					</TR>
				</TFoot>
			</Table>
		)
	}
}