import React from 'react'
import { CircleArrowLeft } from '../../../../app/icons'

export function ToggleAdminPanel() {
	return (
		<span>
			<CircleArrowLeft/>
		</span>
	)
}
