import React from 'react'
import { FaCog } from 'react-icons/fa'

export function IconFaCog() {
	return (
		<span>
			<FaCog />
		</span>
	)
}