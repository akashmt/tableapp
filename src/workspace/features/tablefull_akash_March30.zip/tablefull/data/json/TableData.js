export const TableData = {
  table: {
    fixedHeader: true,
    showFooter: true,
    selectRow: false,
    columns: [ 
      {
        name: "name",
        dataType: "text",
        buttonText: "",
        buttonUrl: "", 
        formatString: "",
        headerText: "My Text Column",
        isKey: true,
        display: true,
        isSearchable: true,
        isSortable: true,
        isSelectDropDown: false
      }, 
      {
        name: "country",
        dataType: "text",
        buttonText: "",
        buttonUrl: "",
        formatString: "",
        headerText: "My Text Country Column",
        isKey: true,
        display: true,
        isSearchable: false,
        isSortable: false,
        isSelectDropDown: true
      },
      {
        name: "price",
        dataType: "currency",
        buttonText: "",
        buttonUrl: "",
        formatString: "decimal", // simple / decimal
        headerText: "My numeric Price Column",
        isKey: true,
        display: true,
        isSearchable: false,
        isSortable: false,
        isSelectDropDown: false
      },
      {
        name: "number",
        dataType: "number",
        buttonText: "",
        buttonUrl: "",
        formatString: "", // simple / decimal
        headerText: "My numeric Number Column",
        isKey: true,
        display: true,
        isSearchable: true,
        isSortable: false,
        isSelectDropDown: false
      },
      {
        name: "percentage",
        dataType: "percent",
        buttonText: "",
        buttonUrl: "",
        formatString: "simple", // simple / decimal
        headerText: "My numeric Percentage Column",
        isKey: true,
        display: true,
        isSearchable: false,
        isSortable: false,
        isSelectDropDown: false
      },
      {
        name: "active",
        dataType: "boolean",
        buttonText: "",
        buttonUrl: "",
        formatString: "true", // 1 / true
        headerText: "My boolean Column",
        isKey: true,
        display: true,
        isSearchable: false,
        isSortable: false,
        isSelectDropDown: false
      },
      {
        name: "date",
        dataType: "date",
        buttonText: "",
        buttonUrl: "",
        formatString: "D-MMM", //  M/D/YY  //  MM/DD/YY  // MM/DD/YYYY  //  MMM D, YY // MMMM D, YYYY  // MM-DD // YY-MM-DD // D-MMM-YY // MMM-YY  // D-MMM
        headerText: "My Date Column",
        isKey: true,
        display: true,
        isSearchable: false,
        isSortable: false,
        isSelectDropDown: false
      }
    ],
    rows: [
      {
        key: "1",
        name: "Akash Patel",
        country: "India",
        price: 100,
        number: 27.5,
        percentage: 12,
        active: 1,
        date: "01/12/2020"
      },
      {
        key: "2",
        name: "john Paul",
        country: "US",
        price: 200,
        number: 37,
        percentage: 34.66,
        active: 1,
        date: "11/30/2020"
      },
      {
        key: "3",
        name: "Steve Smith",
        country: "Australia",
        price: 150,
        number: 43.1,
        decimal: 32300,
        percentage: 44,
        active: 0,
        date: "12/12/2020"
      },
      {
        key: "4",
        name: "Kevin Piter",
        country: "England",
        price: 2150.3,
        number: 23,
        decimal: 320,
        percentage: 32.01,
        active: 1,
        date: "10/11/2020"
      },
      {
        key: "5",
        name: "Akash Patel1",
        country: "India",
        price: 1000.87,
        number: 27.55,
        decimal: 100.0,
        percentage: 12,
        active: 0,
        date: "2/20/2020"
      },
      {
        key: "6",
        name: "john Paul1",
        country: "US",
        price: 2000,
        number: 37,
        decimal: 200.0,
        percentage: 34,
        active: 1,
        date: "11/25/2020"
      },
      {
        key: "7",
        name: "Steve Smith1",
        country: "Australia",
        price: 150,
        number: 43,
        decimal: 300,
        percentage: 44.77,
        active: 0,
        date: "1/01/2020"
      },
      {
        key: "8",
        name: "Kevin Piter1",
        country: "England",
        price: 250,
        number: 23.566,
        decimal: 320,
        percentage: 32.54,
        active: 0,
        date: "04/14/2020"
      }
    ],
  }
}