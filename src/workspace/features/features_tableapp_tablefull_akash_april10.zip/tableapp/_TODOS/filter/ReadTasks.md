# Filter Tasks

Please create individual components, one at a time, then do a simple tutorial video that starts from the very beginning.

* Please use fake data for now

1) TextMatch - user uses an input field to type in a value and filter to closest text match

2) DropDown - user uses a Select Option to filter out data..
-(text) could be used as a Category selector or Table Column Data that has the same value
-(numeric range, sent by backend) could be be used as a range.. 100 to 300, above 200, below 200
-(true/false) could be be used as a boolean selector

3) RangeSelector - here we need 2 numeric values for user to use a Slider to select a range.. use slides from a low value and slides another from a higher value

* Last we need to create a conditional function that sees the the Data and and selects (Switch) the Filter Component we want it to use