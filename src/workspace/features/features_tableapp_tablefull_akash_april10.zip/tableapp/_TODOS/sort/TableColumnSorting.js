import React from 'react'
import { Table } from '../../components'

export function TableColumnSorting() {
	return (
		<Table>
			<h3>Table Column Sorting</h3>
		</Table>
	)
}