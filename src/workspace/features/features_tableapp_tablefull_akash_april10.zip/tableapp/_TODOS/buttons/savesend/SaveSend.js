import React from 'react'
import { Table, Caption, THead, TFoot, TBody, TR, TH, TD } from '../../../components'

// usercontext

export function SaveSend() {
	return (
		<Table>
			<h3>Save Send button</h3>
		</Table>
	)
}