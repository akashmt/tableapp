import React from 'react'

export const PageTitle = ({ children }) => {
	return (
		<h2>
			{children}
		</h2>
	)
}