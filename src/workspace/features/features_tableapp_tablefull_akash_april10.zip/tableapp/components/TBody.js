import React from 'react'

export const TBody = ({ children }) => {
	return (
		<tbody>
			{children}
		</tbody>
	)
}